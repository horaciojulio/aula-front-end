# Meu Projeto de Página Pessoal

Meu nome é Julio Cezar e esse é um projeto que fiz para a faculdade na matéria de Desenvolvimento Web para Front End.

## Como abrir

É só baixar o projeto e abrir o arquivo `index.html` no navegador.

## Páginas

* **Página inicial:** fala um pouco sobre mim, meus interesses, estudos e objetivos.
* **Meus interesses:** tem mais informações sobre meus interesses em tecnologia e sobre o projeto Arena Tech.

## O que usei

* HTML
* CSS
* VS Code
* Google Chrome

Também usei imagens encontradas na internet e coloquei suas fontes no projeto.

O áudio foi gravado por mim.

## Testes

Testei os links, as imagens, o áudio, o formulário e a navegação entre as páginas.

## Uso de IA

Usei IA como ajuda durante o desenvolvimento para tirar algumas dúvidas e entender melhor algumas partes do código.
