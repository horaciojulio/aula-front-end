# Projeto 3 - Painel Interativo com JavaScript

## Tema
Descubra seu caminho no Front-End.

## Integrantes
- Integrante 1: [Nome completo] - RGM: [preencher na identificação da entrega, se solicitado]
- Integrante 2: [Nome completo]
- Integrante 3: [Nome completo]

> Preencha os nomes do grupo. Não coloque telefone, endereço ou outros dados pessoais na página pública.

## Divisão das tarefas
- HTML: estrutura da página, campos, botões e área de resultado.
- CSS: aparência, responsividade e temas claro/escuro.
- JavaScript: seleção dos elementos, validação, mensagens e troca de tema.

## Como o projeto funciona
O visitante digita o nome, escolhe uma área (HTML, CSS ou JavaScript) e clica em "Gerar orientação". O JavaScript lê os campos, verifica se o nome e a área foram preenchidos e usa condições `if/else` para escolher uma mensagem. A mensagem é exibida na própria página. O botão "Alterar tema" adiciona ou remove a classe `tema-escuro` do elemento `body`.

## Comandos JavaScript utilizados
- `document.getElementById()`: localiza elementos pelo ID.
- `const` e `let`: criam variáveis.
- `addEventListener('click', ...)`: executa uma ação quando há clique.
- `.value`: obtém o valor de um campo.
- `.trim()`: remove espaços do começo e do fim do texto.
- `if/else`: escolhe qual orientação será exibida.
- Template string: monta uma mensagem com variáveis, usando crases e `${}`.
- `.textContent`: altera o texto exibido na página.
- `classList.add()` e `classList.remove()`: adicionam ou removem a classe de erro.
- `classList.toggle()`: alterna a classe do tema escuro.

## Arquivos
- `index.html`: estrutura da página.
- `css/estilo.css`: estilos visuais.
- `js/script.js`: comportamento da página.

## Como testar
1. Abra o arquivo `index.html` no navegador.
2. Clique em "Gerar orientação" sem preencher o nome: deve aparecer uma mensagem de erro.
3. Digite um nome e não selecione uma área: deve pedir para escolher uma área.
4. Teste HTML, CSS e JavaScript: cada opção deve mostrar uma orientação diferente.
5. Clique em "Alterar tema": a página deve alternar entre claro e escuro.
6. Diminua a largura da janela ou abra no celular para verificar a responsividade.

## Captura de tela
Insira aqui uma captura da página funcionando antes de entregar.
