// 1. Localizar os elementos do HTML
const campoNome = document.getElementById("nome");
const campoInteresse = document.getElementById("interesse");
const botaoGerar = document.getElementById("btnGerar");
const botaoTema = document.getElementById("btnTema");
const areaResultado = document.getElementById("resultado");

// 2. Função que gera a orientação
function gerarOrientacao() {
    // Ler os valores digitados/selecionados
    const nome = campoNome.value.trim();
    const interesse = campoInteresse.value;

    // Validar o nome
    if (nome === "") {
        areaResultado.textContent = "Por favor, preencha seu nome para continuar.";
        areaResultado.classList.add("erro");
        return; // Encerra a função se o nome estiver vazio
    }

    // Validar a área de interesse
    if (interesse === "") {
        areaResultado.textContent = `Olá, ${nome}! Escolha uma área de interesse para receber sua orientação.`;
        areaResultado.classList.add("erro");
        return;
    }

    // Decidir a mensagem de acordo com a área escolhida
    let orientacao = "";

    if (interesse === "HTML") {
        orientacao = "comece aprendendo as tags, a estrutura de uma página e o HTML semântico.";
    } else if (interesse === "CSS") {
        orientacao = "pratique cores, espaçamentos, Flexbox, Grid e responsividade.";
    } else if (interesse === "JavaScript") {
        orientacao = "estude variáveis, condições, funções, eventos e manipulação do DOM.";
    }

    // Exibir a mensagem na própria página
    areaResultado.textContent = `Olá, ${nome}! Como você escolheu ${interesse}, minha dica é: ${orientacao}`;
    areaResultado.classList.remove("erro");
}

// 3. Executar a função quando o botão for clicado
botaoGerar.addEventListener("click", gerarOrientacao);

// 4. Alternar entre tema claro e escuro
botaoTema.addEventListener("click", function () {
    document.body.classList.toggle("tema-escuro");
});
